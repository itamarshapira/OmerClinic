import Button from '@/Components/UI/Button';
import hero from '@/assets/images/hero.png';
import DescNums from './DescNums';
import SectionWrapper from '../SectionWrapper';

const Home = () => {
  return (
    <SectionWrapper id="בית">
      <div className="flex flex-col-reverse  md:flex-row items-center justify-between gap-10 text-center md:text-left">
        <div className="tracking-wider md:tracking-normal max-w-md lg:max-w-2xl">
         <h1 className="lg:text-3xl text-3xl font-bold text-[#1d4d85]">
  עומר שמידט 
</h1>
<br />
  <h1 className="lg:text-3xl text-3xl font-bold text-[#1d4d85]">
  רפואה סינית
</h1>

<p className="text-lg md:text-base lg:text-xl my-10 text-[#6b5b4d] leading-relaxed">
  טיפול אישי ומקצועי המבוסס על עקרונות הרפואה הסינית,
  לאיזון הגוף והנפש, הפחתת כאבים ושיפור איכות החיים.
</p>

<Button>קביעת תור</Button>
        </div>
        <div className="max-w-xs md:max-w-none">
          <img src={hero} alt="hero" />
        </div>
      </div>
      <DescNums />
    </SectionWrapper>
  );
};

export default Home;
