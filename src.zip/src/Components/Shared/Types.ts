export enum SelectedPage {
  Home = 'בית',
  Doctors = 'מטפלים',
  Services = 'שירותים',
  Reviews = 'המלצות',
}

export enum SelectedService {
  Neurology = 'neurology',
  Cardiology = 'cardiology',
  Orthopedics = 'orthopedics',
  Surgery = 'surgery',
  Dentistry = 'dentistry',
  Radiology = 'radiology',
  Urology = 'urology',
  Medicine = 'medicine',
  SeeMore = 'seemore',
}
